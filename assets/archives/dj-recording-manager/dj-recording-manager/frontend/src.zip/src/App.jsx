import React from 'react';
import Header from './components/Header';
import ScheduleManagement from './components/ScheduleManagement';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <ScheduleManagement />
        </div>
      </main>
    </div>
  );
}

export default App;
