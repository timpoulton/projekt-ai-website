﻿import React from 'react';
import logo from '../assets/club77-globe.png';

const Header = () => {
  return (
    <header className="w-full bg-black border-b border-zinc-800 py-6">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-center">
          <img 
            src={logo} 
            alt="Club 77" 
            className="h-20 w-auto mb-4"
          />
          <h2 className="text-zinc-400 text-sm tracking-wider uppercase">Recording Manager</h2>
        </div>
      </div>
    </header>
  );
}

export default Header;
